package java.lang;

public class Short {

}

