package java.lang;

public class StringBuffer {

}

