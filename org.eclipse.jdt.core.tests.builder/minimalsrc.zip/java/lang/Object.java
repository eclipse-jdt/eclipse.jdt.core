package java.lang;

public class Object {

protected Object clone() throws CloneNotSupportedException {
	return null;
}

public boolean equals (Object o) {
	return false;
}

public final Class getClass() {
	return null;
}

public int hashCode() {
	return -1;
}

public final void notify() {
}

public final void notifyAll() {
}

public String toString () {
	return null;
}

public final void wait () throws InterruptedException {
}

public final void wait (long time) throws InterruptedException {
}

public final void wait (long time, int frac) throws InterruptedException {
}
}
