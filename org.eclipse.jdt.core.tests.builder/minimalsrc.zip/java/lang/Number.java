package java.lang;

public class Number {

}

