package java.lang;

public class Float {

}

