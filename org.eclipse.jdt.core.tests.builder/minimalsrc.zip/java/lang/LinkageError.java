package java.lang;

public class LinkageError extends Error {

}

