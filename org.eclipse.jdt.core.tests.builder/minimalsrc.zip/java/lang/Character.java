package java.lang;

public class Character {

}

