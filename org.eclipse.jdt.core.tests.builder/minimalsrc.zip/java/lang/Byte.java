package java.lang;

public class Byte {

}

