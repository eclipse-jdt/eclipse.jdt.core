package java.lang;

public class Long {

}

