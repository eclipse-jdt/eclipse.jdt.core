package java.lang;

public class Double {

}

