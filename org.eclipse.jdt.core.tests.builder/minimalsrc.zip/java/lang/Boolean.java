package java.lang;

public final class Boolean implements java.io.Serializable {

public Boolean (String string) {
}

public Boolean (boolean value) {
}

public boolean booleanValue () {
	return false;
}

public boolean equals (Object o) {
	return false;
}

public int hashCode() {
	return -1;
}

public static boolean getBoolean(String string) {
	return false;
}

public String toString () {
	return null;
}

public static Boolean valueOf(String string) {
	return null;
}

}
