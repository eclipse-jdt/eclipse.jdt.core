package java.io;

public class PrintStream {
	public void print(){}
	public void print(char c){}
	public void print(char[] c){}
	public void print(double d){}
	public void print(float f){}
	public void print(int i){}
	public void print(long l){}
	public void print(Object o){}
	public void print(String s){}
	public void print(boolean b){}
	public void println(){}
	public void println(char c){}
	public void println(char[] c){}
	public void println(double d){}
	public void println(float f){}
	public void println(int i){}
	public void println(long l){}
	public void println(Object o){}
	public void println(String s){}
	public void println(boolean b){}
}

