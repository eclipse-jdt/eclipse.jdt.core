package test;

public class Foo {
	public static class Bar<A, B> {
	}

	public static void gotchaFunc1(Bar<byte[], Object> bar) {
	}
	public static void gotchaFunc2(Bar<boolean[], Object> bar) {
	}
	public static void gotchaFunc3(Bar<char[], Object> bar) {
	}
	public static void gotchaFunc4(Bar<double[], Object> bar) {
	}
	public static void gotchaFunc5(Bar<float[], Object> bar) {
	}
	public static void gotchaFunc6(Bar<int[], Object> bar) {
	}
	public static void gotchaFunc7(Bar<long[], Object> bar) {
	}
	public static void gotchaFunc8(Bar<short[], Object> bar) {
	}
}
