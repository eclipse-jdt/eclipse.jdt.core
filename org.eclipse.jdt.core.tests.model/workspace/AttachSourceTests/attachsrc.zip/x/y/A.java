package x.y;
public class A {
	class Inner {
	}
	public A() {
	}
	public void foo() {
	}
}
