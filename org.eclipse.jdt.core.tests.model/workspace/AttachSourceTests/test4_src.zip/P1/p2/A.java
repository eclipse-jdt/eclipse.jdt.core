package P1.p2;

public class A {}