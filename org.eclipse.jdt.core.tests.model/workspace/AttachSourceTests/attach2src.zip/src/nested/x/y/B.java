package x.y;
public class B {
}
