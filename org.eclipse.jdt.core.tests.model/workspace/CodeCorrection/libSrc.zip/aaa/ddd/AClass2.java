package aaa.ddd;

public class AClass2 {

}
