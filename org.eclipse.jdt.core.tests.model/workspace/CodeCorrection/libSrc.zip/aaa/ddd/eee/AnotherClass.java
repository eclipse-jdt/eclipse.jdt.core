package aaa.ddd.eee;

public class AnotherClass {

}
