package aaa.bbb;

public class AnException extends Exception {

}
