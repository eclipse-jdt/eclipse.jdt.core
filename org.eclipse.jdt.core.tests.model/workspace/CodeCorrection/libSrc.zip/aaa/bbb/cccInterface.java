package aaa.bbb;

public interface cccInterface {

}
