package p4;

public class X {
	Object o;
}
