package p3;

public class X {
	Object o;
}
