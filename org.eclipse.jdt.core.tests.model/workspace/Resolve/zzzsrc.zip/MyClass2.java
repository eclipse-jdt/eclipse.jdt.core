public class MyClass2 {
	class Inner {}
	void method(MyClass2.Inner[] arg){}
	void foo(){
		method(new MyClass2.Inner[0]);
	}	
}
