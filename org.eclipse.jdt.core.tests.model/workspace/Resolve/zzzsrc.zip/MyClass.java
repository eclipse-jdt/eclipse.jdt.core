public class MyClass {
	
	class Inner {
		public void foo() { }
	}
	
	public void test() { }
	
	public void callsTest() {
		test();
	}

}