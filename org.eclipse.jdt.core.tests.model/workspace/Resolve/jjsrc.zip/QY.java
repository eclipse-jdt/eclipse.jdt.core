public class QY extends QX {
	public void foo() {
	}
}
