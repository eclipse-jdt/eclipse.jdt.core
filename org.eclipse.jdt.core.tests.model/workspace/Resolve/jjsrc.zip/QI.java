public interface QI {
	void foo();
}