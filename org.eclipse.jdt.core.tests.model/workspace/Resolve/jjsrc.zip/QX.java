public abstract class QX implements QI {

}
