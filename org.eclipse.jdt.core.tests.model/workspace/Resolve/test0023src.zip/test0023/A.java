package test0023;

public class A<U> {
	public class B {
		public class D<V> {
		}
	}
	public class C<W> {
	}
}
