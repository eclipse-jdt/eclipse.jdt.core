package test0023;

public class X {
	public <T extends Y> void add(T t, A<T> a, A<T>.B b, A<T>.C<T> c, A<T>.B.D<T> d, E e, E.F<T> f) {
		
	}
	
	public <T extends Y> void rem(AA.BB.CC cc) {
		
	}
}