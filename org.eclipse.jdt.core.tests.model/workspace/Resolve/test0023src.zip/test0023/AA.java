package test0023;

public class AA {
	public class BB {
		public class CC {
			
		}
	}
}
