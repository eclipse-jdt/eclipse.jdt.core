package test0023;

public class Y {

}
