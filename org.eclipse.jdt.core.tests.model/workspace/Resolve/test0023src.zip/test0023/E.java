package test0023;

public class E {
	public class F <P> {
	}
}
