public class ResolveStaticClassConstructor {
	public static class StaticInnerClass {
		public StaticInnerClass(){
		}
	}
	public void foo() {
		new StaticInnerClass();
	} 
}
