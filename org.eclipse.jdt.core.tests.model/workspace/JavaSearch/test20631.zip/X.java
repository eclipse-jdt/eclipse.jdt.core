public class X {
void foo() {
	class Y {}
	System.out.println(new Y().toString());
}
}
