package AbortCompilation;

public class MissingArgumentType {
public void foo() {
}
public void foo(java.util.EventListener e) {
}
public void foo2() {
}
}
