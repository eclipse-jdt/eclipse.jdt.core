package AbortCompilation;

public class MissingFieldType {
	Object field;
	java.util.EventListener missing;
	String otherField;
}
