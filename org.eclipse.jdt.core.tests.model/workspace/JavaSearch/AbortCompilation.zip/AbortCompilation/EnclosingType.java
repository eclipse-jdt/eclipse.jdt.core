package AbortCompilation;

public class EnclosingType {
	public class MissingEnclosingType {
	}
}
