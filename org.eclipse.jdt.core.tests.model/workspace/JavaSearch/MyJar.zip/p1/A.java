package p1;

public class A {
	
	int field;
	
	A(String s) {
	}
	
	public boolean foo(String s) {
		return false;
	}

}
