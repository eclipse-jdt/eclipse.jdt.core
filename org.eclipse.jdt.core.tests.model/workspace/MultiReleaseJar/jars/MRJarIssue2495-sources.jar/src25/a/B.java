package a;

public class B {
	public void foo() {}
}
