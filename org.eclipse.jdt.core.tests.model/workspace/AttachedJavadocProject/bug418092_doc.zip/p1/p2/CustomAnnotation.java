package p1.p2;

import java.lang.annotation.Documented;

@Documented
public @interface CustomAnnotation {
  String value();
}
