package p1.p2;

/**
 * Here is the code needed to generate this Javadoc
 * <p>
 * In CustomAnnotation.java:
 * <pre>
 * package p1.p2;
 *
 * import java.lang.annotation.Documented;
 *
 * &#64;Documented
 * public &#64;interface CustomAnnotation {
 *   String value();
 * }
 * </pre>
 * <p>
 * In AnnotC.java:
 * <pre>
 * package p1.p2;
 *
 * public class AnnotC {
 *   &#64;CustomAnnotation("test")
 *   public static void filter(int p1, int p2) {
 *   }
 * }
 * </pre>
 */
public class Annot3 {
  @CustomAnnotation("test")
  public static void filter(int p1, int p2) {
  }
}
