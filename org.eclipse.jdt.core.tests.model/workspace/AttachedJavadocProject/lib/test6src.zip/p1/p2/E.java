package p1.p2;

/**
 * Declaration of enum type E
 */
public enum E {

	/**
	 * Constant D
	 */
	D,
	/**
	 * Constant C
	 */
	C;
	
	public String field;
}
