package p1.p2;

public @interface Annot {
	String name();
	String name2() default "";
	public class D {}
}
