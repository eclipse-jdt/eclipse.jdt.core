package p1.p2.p3;

public class D<E> {

}
