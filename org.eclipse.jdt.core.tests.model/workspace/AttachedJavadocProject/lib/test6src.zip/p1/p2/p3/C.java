package p1.p2.p3;

import java.util.Map;

public interface C<E> {
    /**
     * Javadoc for d()
     */
    D<E> d();

    /**
     * Javadoc for bar()
     */
    Object[] bar();

    /**
     * Javadoc for foo(T[])
     */
    <T> T[] toArray(T[] a);


    /**
     * Javadoc for m(E)
     */
    boolean m(E o);

    /**
     * Javadoc for bar4
     */
    boolean bar4(int i, D<? extends E> c);

    /**
     * Javadoc for bar3
     */
    boolean bar3(D<?> c);

    /**
     * Javadoc for bar5
     */
    public <K,V> Map<K,V> bar5(Map<K,V> m, int j, Map<K,V> m2);
    
    /**
     * Javadoc of equals
     */
    boolean equals(Object o);

    /**
     * Javadoc for bar1
     */
    E bar1(int i, E e);

    /**
     * Javadoc for m1
     */
    void m1(int i, E e);

    /**
     * Javadoc for m2
     */
    E m2(int index);
}
