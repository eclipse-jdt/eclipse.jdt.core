package p2;
public class X {
	/**
	 * test case for bug 140879 Spontaneous error "java.util.Set cannot be resolved..."
	 */
	public p2.Z<String> foo() {
		return null;
	}
}
