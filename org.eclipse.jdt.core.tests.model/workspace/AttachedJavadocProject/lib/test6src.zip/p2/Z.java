package p2;
public class Z<T> {
}
