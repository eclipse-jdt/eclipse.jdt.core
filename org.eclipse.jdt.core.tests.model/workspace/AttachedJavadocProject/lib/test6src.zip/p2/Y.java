package p2;
public class Y extends X {
	public Z<String> foo() {
		return super.foo();
	}
}
