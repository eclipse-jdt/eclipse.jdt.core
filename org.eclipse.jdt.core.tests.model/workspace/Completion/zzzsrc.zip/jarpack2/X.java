package jarpack2;

public class X {
	Object o;
}
