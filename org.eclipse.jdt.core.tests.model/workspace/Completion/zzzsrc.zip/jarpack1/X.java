package jarpack1;

public class X {
	Object o;
}
