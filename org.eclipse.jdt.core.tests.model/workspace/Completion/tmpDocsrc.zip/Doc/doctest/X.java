package doctest;

public class X {
	public void foo(Object param) {
	}
}
