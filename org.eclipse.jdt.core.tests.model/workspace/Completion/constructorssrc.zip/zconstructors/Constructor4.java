package zconstructors;

public class Constructor4 {
	public Constructor4(int i){}
}
