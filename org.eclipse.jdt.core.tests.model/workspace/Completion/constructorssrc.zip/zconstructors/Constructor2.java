package zconstructors;

public class Constructor2 {

}
