package zconstructors;

public class Constructor3 {
	public Constructor3() {}
}
