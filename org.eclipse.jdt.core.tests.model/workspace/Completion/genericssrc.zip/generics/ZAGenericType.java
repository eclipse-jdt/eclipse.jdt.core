package generics;

public class ZAGenericType<T> {
	public T foo(T t) {
		return null;
	}
	public <U> U foo(ZAGenericType<? extends T> var) {
		return null;
	}
}
