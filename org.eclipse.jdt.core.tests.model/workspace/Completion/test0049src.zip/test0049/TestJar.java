package test0049;

public class TestJar<E> {
	void bar(E e) {
	}
}
