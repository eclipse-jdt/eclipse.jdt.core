public final class Float extends Number{
}

