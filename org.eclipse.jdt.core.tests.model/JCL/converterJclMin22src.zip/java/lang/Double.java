package java.lang;
public final class Double extends Number{
    public boolean isInfinite() {
        return true;
    }
}

