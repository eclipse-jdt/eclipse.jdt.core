public final class Double extends Number{
}

