package java.lang;

public class Class<T> {
}
