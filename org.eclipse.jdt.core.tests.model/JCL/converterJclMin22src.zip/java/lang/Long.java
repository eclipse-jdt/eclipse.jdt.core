public final class Long extends Number{
}
