package java.lang;

public class IllegalAccessException extends RuntimeException {

}
