package java.io;

public class InputStream {

}
