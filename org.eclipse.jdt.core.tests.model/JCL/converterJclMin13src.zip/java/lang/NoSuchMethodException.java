package java.lang;

public class NoSuchMethodException extends RuntimeException {

}
