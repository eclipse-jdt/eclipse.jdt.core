package java.io;

public interface Serializable {
}
