package java.lang;


public final class StringBuilder {

    public StringBuilder() {
    }

    public StringBuilder(int capacity) {
    }

    public StringBuilder(String str) {
    }

    public StringBuilder(CharSequence seq) {
    }

    public StringBuilder append(Object obj) {
        return this;
    }

    public StringBuilder append(String str) {
        return this;
    }

    public StringBuilder append(StringBuffer sb) {
        return this;
    }

    public StringBuilder append(CharSequence s) {
        return this;
    }

    public StringBuilder append(CharSequence s, int start, int end) {
        return this;
    }

    public StringBuilder append(char[] str) {
        return this;
    }

    public StringBuilder append(char[] str, int offset, int len) {
        return this;
    }

    public StringBuilder append(boolean b) {
        return this;
    }

    public StringBuilder append(char c) {
        return this;
    }


    public StringBuilder append(int i) {
        return this;
    }


    public StringBuilder append(long lng) {
        return this;
    }


    public StringBuilder append(float f) {
        return this;
    }


    public StringBuilder append(double d) {
        return this;
    }

    public StringBuilder appendCodePoint(int codePoint) {
        return this;
    }

    public StringBuilder delete(int start, int end) {
        return this;
    }

    public StringBuilder deleteCharAt(int index) {
        return this;
    }

    public StringBuilder replace(int start, int end, String str) {
        return this;
    }

    public StringBuilder insert(int index, char[] str, int offset, int len)  {
        return this;
    }

    public StringBuilder insert(int offset, Object obj) {
            return this;
    }

    public StringBuilder insert(int offset, String str) {
        return this;
    }

    public StringBuilder insert(int offset, char[] str) {
        return this;
    }

    public StringBuilder insert(int dstOffset, CharSequence s) {
            return this;
    }

    public StringBuilder insert(int dstOffset, CharSequence s, int start, int end) {
        return this;
    }

    public StringBuilder insert(int offset, boolean b) {
        return this;
    }

    public StringBuilder insert(int offset, char c) {
        return this;
    }


    public StringBuilder insert(int offset, int i) {
        return this;
    }

    public StringBuilder insert(int offset, long l) {
        return this;
    }

    public StringBuilder insert(int offset, float f) {
        return this;
    }

    public StringBuilder insert(int offset, double d) {
        return this;
    }

    public int indexOf(String str) {
        return 0;
    }

    public int indexOf(String str, int fromIndex) {
        return 0;
    }

    public int lastIndexOf(String str) {
        return 0;
    }

    public int lastIndexOf(String str, int fromIndex) {
        return 0;
    }

    public StringBuilder reverse() {
        return this;
    }

    public String toString() {
        return "";
    }


}
