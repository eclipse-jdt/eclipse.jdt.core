package java.util;

public interface RandomAccess {}
