package java.lang;

public class Object {

public Object() {
}
protected Object clone() throws CloneNotSupportedException {
	return null;
}
public boolean equals (Object obj) {
	return false;
}
protected void finalize () throws Throwable {
}
public final Class<? extends Object> getClass() {
	return null;
}
public int hashCode() {
	return -1;
}
public final void notify() throws IllegalMonitorStateException {
}
public final void notifyAll() throws IllegalMonitorStateException {
}
public String toString () {
	return null;
}
public final void wait () throws IllegalMonitorStateException, InterruptedException {
}
public final void wait (long millis) throws IllegalMonitorStateException, InterruptedException {
}
public final void wait (long millis, int nanos) throws IllegalMonitorStateException, InterruptedException {
}
}
