package java.lang;
public final class Float extends Number{
	public boolean isInfinite() {
		return true;
	}
}


