package java.lang;

public abstract class Number implements java.io.Serializable {
}
