package java.lang;

public class Integer extends Number implements Comparable<Integer> {
	private static final long serialVersionUID = 6462609062775655000L;

	public Integer(int i) {
	}
	public Integer(String s) {
	}
	public static final int MAX_VALUE= 2147483647;
	public static final int MIN_VALUE= -2147483647;
	
	public static int parseInt(String s) {
		return 0;
	}
	public static String toHexString(int i) {
		return null;
	}
	public static String toString(int i) {
		return null;
	}
	/* (non-Javadoc)
	 * @see java.lang.Number#doubleValue()
	 */
	public double doubleValue() {
		return 0;
	}
	/* (non-Javadoc)
	 * @see java.lang.Number#floatValue()
	 */
	public float floatValue() {
		return 0;
	}
	/* (non-Javadoc)
	 * @see java.lang.Number#intValue()
	 */
	public int intValue() {
		return 0;
	}
	/* (non-Javadoc)
	 * @see java.lang.Number#longValue()
	 */
	public long longValue() {
		return 0;
	}
	public int compareTo(Integer i) {
		return 0;
	}
}
