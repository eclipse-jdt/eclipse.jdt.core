package java.lang.invoke;

public interface TypeDescriptor {
    String descriptorString();
}
