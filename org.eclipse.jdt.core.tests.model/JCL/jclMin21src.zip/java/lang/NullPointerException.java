package java.lang;
public
class NullPointerException extends RuntimeException {
    public NullPointerException() {
        super();
    }

    public NullPointerException(String s) {
        super(s);
    }
}