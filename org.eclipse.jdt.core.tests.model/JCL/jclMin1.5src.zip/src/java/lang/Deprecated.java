package java.lang;
public @interface Deprecated {
}
