package java.util;

public class Calendar {
	public static final int THURSDAY = 5;
}
