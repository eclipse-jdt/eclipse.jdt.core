package java.lang.annotation;

public interface Annotation {

}
