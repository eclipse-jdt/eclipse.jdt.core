package javax.swing;

public class BoxLayout {
	public static final int LINE_AXIS = 2;
	public static final int PAGE_AXIS = 3;
}
