module java.base {
	exports java.lang;
	exports java.lang.annotation;
	exports java.lang.invoke;
	exports java.io;
	exports java.util;
}
