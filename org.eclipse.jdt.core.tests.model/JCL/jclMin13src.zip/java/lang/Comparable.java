package java.lang;

public interface Comparable<T> {
}
