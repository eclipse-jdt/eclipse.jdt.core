package java.lang.invoke;

public class TypeDescriptor {

}
