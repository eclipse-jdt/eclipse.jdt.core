package java.util.function;

public interface Predicate<T> {
    boolean test(T t);
}