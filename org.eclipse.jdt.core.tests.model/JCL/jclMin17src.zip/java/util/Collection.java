package java.util;

public interface Collection<T> extends Iterable<T> {
    Iterator<T> iterator();
    int size();
    T get(int index);
    public boolean addAll(Collection<? extends T> c);
    T[] toArray(T[] o);
}