package java.util;

public interface Collection<T> extends Iterable<T> {
	public Iterator<T> iterator();
	public int size();
	public T get(int index);
	public boolean addAll(Collection<? extends T> c);
	public T[] toArray(T[] o);
}
