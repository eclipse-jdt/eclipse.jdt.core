package java.lang;

public class String implements Comparable<String>, CharSequence {
	public int length() { return 0; }
}
