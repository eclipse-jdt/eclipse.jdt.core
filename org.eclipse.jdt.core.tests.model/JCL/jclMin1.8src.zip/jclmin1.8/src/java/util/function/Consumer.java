package java.util.function;

public interface Consumer<T> {
    void accept(T t);
}
