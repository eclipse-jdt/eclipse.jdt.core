package java.util;

public interface Enumeration {

	public boolean hasMoreElements();
	
	public Object nextElement();
}
