package java.util;

public class Vector {

}
