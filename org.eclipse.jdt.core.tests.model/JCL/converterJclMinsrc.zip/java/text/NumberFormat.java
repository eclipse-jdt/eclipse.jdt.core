package java.text;

public class NumberFormat {

    public final static NumberFormat getInstance() {
    	return null;
    }
    
    public final String format (double d) {
    	return null;
    }
}
