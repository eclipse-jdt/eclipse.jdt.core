package java.awt;

public class Point {
	public int x;
	public int y;
}
