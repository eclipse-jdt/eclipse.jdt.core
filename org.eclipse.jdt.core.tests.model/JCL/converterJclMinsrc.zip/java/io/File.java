package java.io;

public class File {

}
