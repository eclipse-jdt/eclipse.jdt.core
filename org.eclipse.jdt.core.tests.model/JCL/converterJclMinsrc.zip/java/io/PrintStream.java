package java.io;

public class PrintStream {

	public void println() {
	}
	
	public void println(String s) {
	}
}
