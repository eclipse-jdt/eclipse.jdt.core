package java.io;

public class InterruptedIOException extends Exception {

}
