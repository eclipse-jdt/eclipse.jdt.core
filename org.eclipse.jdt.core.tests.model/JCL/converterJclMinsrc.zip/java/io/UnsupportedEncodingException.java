package java.io;

public class UnsupportedEncodingException extends Exception {

}
