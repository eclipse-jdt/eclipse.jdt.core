package java.lang;

import java.io.PrintStream;

public class System {

	public static PrintStream err;
	public static PrintStream out;
}
