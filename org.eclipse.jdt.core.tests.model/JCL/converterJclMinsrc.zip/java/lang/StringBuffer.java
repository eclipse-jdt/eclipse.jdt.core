package java.lang;

public class StringBuffer {

	public StringBuffer(String s) {
	}
}
