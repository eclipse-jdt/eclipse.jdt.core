package java.lang;

/**
 * @author oliviert
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class Exception extends Throwable {
	
	/**
	 * Constructor for Exception.
	 */
	public Exception() {
		super();
	}

	/**
	 * Constructor for Exception.
	 * @param s
	 */
	public Exception(String s) {
		super(s);
	}

}
