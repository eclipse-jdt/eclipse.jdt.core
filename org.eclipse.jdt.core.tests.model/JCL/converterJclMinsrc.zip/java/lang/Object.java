package java.lang;

public class Object {

	public String toString() {
		return null;
	}
}
