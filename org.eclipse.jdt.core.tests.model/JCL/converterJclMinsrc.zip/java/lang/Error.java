package java.lang;

public class Error extends Throwable {
	/**
	 * Constructor for Error.
	 */
	public Error() {
		super();
	}

	/**
	 * Constructor for Error.
	 * @param s
	 */
	public Error(String s) {
		super(s);
	}

}
