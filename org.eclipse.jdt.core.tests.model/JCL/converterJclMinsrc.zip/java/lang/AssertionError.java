package java.lang;

public class AssertionError extends Error {

	/**
	 * Constructor for AssertionError.
	 * @param s
	 */
	public AssertionError(String s) {
		super(s);
	}

	/**
	 * Constructor for AssertionError.
	 */
	public AssertionError() {
		super();
	}

}
