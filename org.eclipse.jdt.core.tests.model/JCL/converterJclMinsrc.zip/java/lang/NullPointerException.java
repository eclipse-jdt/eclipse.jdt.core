package java.lang;

public class NullPointerException extends RuntimeException {

	/**
	 * Constructor for NullPointerException.
	 * @param s
	 */
	public NullPointerException(String s) {
		super(s);
	}

	/**
	 * Constructor for NullPointerException.
	 */
	public NullPointerException() {
		super();
	}

}
