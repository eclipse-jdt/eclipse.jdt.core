package java.lang;

public class NullPointerException extends Exception {

	/**
	 * Constructor for NullPointerException.
	 * @param s
	 */
	public NullPointerException(String s) {
		super(s);
	}

	/**
	 * Constructor for NullPointerException.
	 */
	public NullPointerException() {
		super();
	}

}
