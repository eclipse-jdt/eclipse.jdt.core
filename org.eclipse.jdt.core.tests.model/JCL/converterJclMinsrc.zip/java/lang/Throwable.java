package java.lang;

public class Throwable {
	
	public Throwable() {
	}
	
	public Throwable(String s) {
	}

	public void printStackTrace() {
	}
}
