package java.lang;

public interface Runnable {
	
	void run();
}
