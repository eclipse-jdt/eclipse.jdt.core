package java.lang;

public class RuntimeException extends Exception {

	/**
	 * Constructor for RuntimeException.
	 */
	public RuntimeException() {
		super();
	}

	/**
	 * Constructor for RuntimeException.
	 * @param s
	 */
	public RuntimeException(String s) {
		super(s);
	}

}
