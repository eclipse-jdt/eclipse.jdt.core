package java.lang;

import java.io.InputStream;

public class Class {
	public String getName() {
		return null;
	}
	public InputStream getResourceAsStream(String s) {
		return null;
	}
}
