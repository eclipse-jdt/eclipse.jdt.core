/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package java.lang;

public class String {
	public String() {
	}
	public String(char[] source) {
	}
	public String(String s) {
	}
	public String(char[] source, int i , int j) {
	}
	public int length() {
		return 0;
	}
	public String replace(char oldChar, char newChar) {
		return null;
	}

	public int lastIndexOf(char c) {
		return 0;
	}

	public String substring(int i, int j) {
		return null;
	}
	public String substring(int i) {
		return null;
	}
	public char[] toCharArray() {
		return null;
	}
	public int indexOf(String s) {
		return 0;
	}
	public int indexOf(String s, int i) {
		return 0;
	}
	public boolean endsWith(String s) {
		return false;
	}
	public static String valueOf(int i) {
		return null;
	}
	public static String valueOf(Object o) {
		return null;
	}
	public static String valueOf(char[] tab) {
		return null;
	}
	public static String valueOf(char[] tab, int i, int j) {
		return null;
	}
	public int compareTo(String s) {
		return 0;
	}
    public int indexOf(int ch, int fromIndex) {
    	return 0;
    }
    public char charAt(int i) {
    	return ' ';
    }
    public String trim() {
    	return null;
    }
}
