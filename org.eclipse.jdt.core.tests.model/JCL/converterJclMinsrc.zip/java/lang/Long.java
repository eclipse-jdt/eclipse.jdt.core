package java.lang;

public class Long {
	public static long MAX_VALUE = 0x7FFFFFFFFFFFFFFFL;
}
