package java.net;

public class MalformedURLException extends Exception {

}
