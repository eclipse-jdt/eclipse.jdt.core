package java.lang;

public class String implements CharSequence {
	public int length() { return 0; }
	 public int codePointAt(int index) {
		 return 0;
	 }
}
