package p1.p2;

/**
 * Test case for bug 147875
 */
public enum MyEnum {

	@Annot(MyEnum.B)
	A,
	@Annot(MyEnum.C)
	B,
	@Annot(MyEnum.A)
	C,
	@Annot(MyEnum.D)
	D;
	
}
