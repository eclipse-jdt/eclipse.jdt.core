package p1.p2;

/**
 * Test case for bug 147875
 */
public @interface Annot {
	MyEnum2 value();
}
