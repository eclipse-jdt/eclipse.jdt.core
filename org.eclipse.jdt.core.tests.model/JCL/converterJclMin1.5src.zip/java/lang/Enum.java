package java.lang;

public abstract class Enum<T extends Enum<T>> implements Comparable<T>,
		java.io.Serializable {
	protected Enum(String name, int ordinal) {
	}

	public final String name() {
		return null;
	}

	public final int ordinal() {
		return 0;
	}

	public final int compareTo(T o) {
		Enum other = (Enum) o;
		Enum self = this;
		if (self.getClass() != other.getClass() && // optimization
				self.getDeclaringClass() != other.getDeclaringClass())
			throw new ClassCastException();
		return self.ordinal() - other.ordinal();
	}

	public final Class<T> getDeclaringClass() {
		Class clazz = getClass();
		Class zuper = clazz.getSuperclass();
		return (zuper == Enum.class) ? clazz : zuper;
	}
}