package java.lang;

import java.io.InputStream;

public class Class<T> {
	public String getName() {
		return null;
	}
	public InputStream getResourceAsStream(String s) {
		return null;
	}
	
    public native Class<? super T> getSuperclass();
}
