package java.util;

public abstract class AbstractSet<E> extends AbstractCollection<E> implements Set<E> {
}