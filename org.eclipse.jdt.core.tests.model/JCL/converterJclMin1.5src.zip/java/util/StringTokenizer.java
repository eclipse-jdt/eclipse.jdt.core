package java.util;

public class StringTokenizer {

	public StringTokenizer(String toBeParsed, String delimiters) {
	}
	
	public int countTokens() {
		return 0;
	}
	
	public String nextToken() {
		return null;
	}
	
	public boolean hasMoreTokens() {
		return false;
	}
}
