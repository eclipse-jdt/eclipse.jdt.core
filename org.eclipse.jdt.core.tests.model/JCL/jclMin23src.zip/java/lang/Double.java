package java.lang;
public final class Double extends Number{
}

