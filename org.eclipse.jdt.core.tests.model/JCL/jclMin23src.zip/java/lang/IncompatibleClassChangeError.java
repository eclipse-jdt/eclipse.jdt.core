
package java.lang;
public
class IncompatibleClassChangeError extends LinkageError {

    public IncompatibleClassChangeError () {
        super();
    }

    public IncompatibleClassChangeError(String s) {
        super(s);
    }
}
