package java.util;

public interface Set<T> extends Collection<T> {
	static <E> Set<E> of() { return null; }
	static <E> Set<E> of(E e1) { return null; }
	static <E> Set<E> of(E e1, E e2) { return null; }
	static <E> Set<E> of(E... elements) { return null; }
}
