package java.lang;
public interface AutoCloseable {
	void close() throws Exception;
}