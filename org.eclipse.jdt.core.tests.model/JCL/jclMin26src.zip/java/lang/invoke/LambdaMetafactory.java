package java.lang.invoke;
public class LambdaMetafactory {
}