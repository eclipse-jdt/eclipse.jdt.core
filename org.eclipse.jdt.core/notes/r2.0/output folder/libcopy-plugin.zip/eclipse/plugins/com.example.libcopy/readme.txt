Notes on the Library Copying Builder Plug-in

Jim des Rivieres, OTI
November 16, 2001

The com.example.libcopy plug-in illustrates two things:

(1) How to copy additional class files into a Java project's output folder.
This is done using a incremental project builder that runs after the Java
builder.

(2) How to remove any class files in a library folder for which there are
corresponding source files in a source folder. This is done by walking
the Java model to discover the names of the top-level types declared in
source, and then walking the resources in the library folder and deleting
and class files with names matching <type>.class or <type>$*.class.


Installation

The file libcopy-plugin.zip should be extracted into the eclipse/plugins/
directory of an Eclipse install (1.0 or better). When correctly installed,
an extra menu labeled "Extras" appears on the main menu after Eclipse is
re-launched.

There are 3 items on this menu:
	Minimize Project
	Install Library Copying Builder on Project
	Uninstall Library Copying Builder on Project
These actions affect the project currently selected in the Navigator View.

Following these steps to see these in action:
1. Turn off auto-builds (from Window > Preferences).
2. Create a new Java project named "Test"
	- source folder "src",
	- output folder "bin"
	- library folder "classes"
3. Switch to the Resource Perspective and select Test in the Navigator.
4. Select Extras > Install Library Copying Builder on Project.
5. Import class files from eclipse/startup.jar into /Test/classes/.
6. Select Project > Rebuild All

The class files from /Test/classes are copied into /Test/bin/.

7. Import source files from eclipse/startupsrc.zip into /Test/src.
8. Select Project > Build (or Rebuild All)

The class files in /Test/bin/ get replaced by ones that the compiler
generates.

9. Delete the source file UIMain.java.
10. Select Project > Rebuild All

The class files in /Test/bin/ are now a mixture of ones that the compiler
generates and ones copied from the classes folder. Generated ones always
take precedence over a copy.

11. Select Test in the Navigator.
12. Select Extras > Minimize Project.

The class files in /Test/classes/ for which there are corresponding source
files in /Test/src/ have been deleted. There is no source code for the
remaining class files.

That's about it. Complete source code is provided. See LibCopyBuilder.java and
MinimizeLib.java for details. The known limitations of the approach are 
also documented there.
